<?php
require __DIR__ . '/db.php';
$pdo = require __DIR__ . '/db.php';

$pdo->exec("CREATE TABLE IF NOT EXISTS blog_admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  last_login_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$pdo->exec("CREATE TABLE IF NOT EXISTS blog_posts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  slug VARCHAR(255) NOT NULL UNIQUE,
  category VARCHAR(100) NULL,
  excerpt TEXT NULL,
  content_html LONGTEXT NOT NULL,
  cover_image VARCHAR(500) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'draft',
  published_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Create admin user if not exists
$check = $pdo->prepare('SELECT COUNT(*) FROM blog_admins WHERE username = ?');
$check->execute(['admin']);
if ($check->fetchColumn() == 0) {
    $hash = password_hash('KryptonAdmin2026!', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO blog_admins (username, password_hash) VALUES (?, ?)');
    $stmt->execute(['admin', $hash]);
    echo json_encode(['ok' => true, 'message' => 'Tables created, admin user created', 'username' => 'admin', 'password' => 'KryptonAdmin2026!']);
} else {
    echo json_encode(['ok' => true, 'message' => 'Tables created, admin already exists']);
}
exit;
PY